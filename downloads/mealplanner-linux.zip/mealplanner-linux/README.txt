To use this software:

	1. Copy "meal_planner" folder to "Documents" folder
	   Do not delete this folder. This is where
	   all the programs data is stored.

	2. Run program with "./mealplanner"