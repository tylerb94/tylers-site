To use this software:

	No install needed.

	1. Copy "meal_planner" folder to "My Documents"
	   Do not delete this folder. This is where
	   all the programs data is stored.

	2. Place meal_planner.exe in any folder.
	   All *.dll files MUST be in the same folder as mean_planner.exe
	   or it will not work.

	3. Create shortcut to .exe file in any place to open conveniently
	   (Right click -> Copy)
	   Go to shortcut destination. Desktop for example (Right click -> Paste Shortcut)

