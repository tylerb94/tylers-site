#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QDir>
#include <QTextStream>
#include <QInputDialog>
#include <QMessageBox>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:

    // Buttons
    void on_EditButton_clicked();
    void on_SaveButton_clicked();
    void on_ClearListButton_clicked();

    // Calendar
    void on_Calendar_selectionChanged();
    void on_AddItemButton_clicked();
    void on_DeleteItemButton_clicked();

private:

    // Variables
    QString list_save_path = QDir::homePath() + "/Documents/meal_planner/data/list.txt";
    QString meal_save_path = QDir::homePath() + "/Documents/meal_planner/data/saved_meals/";

    // Functions
    // ---------
    // Actions
    void save_grocery_list();
    // Modes
    void set_mode_readonly();
    void set_mode_edit();

    // List Files
    QStringList get_all_meal_files();

    // Read Files
    QString load_file_text(QString filepath);

    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
