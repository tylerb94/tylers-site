#include "mainwindow.h"
#include "ui_mainwindow.h"

// Setup
MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Set editor to read-only
    set_mode_readonly();
    // Load saved grocery list
    QFile file(this->list_save_path);
    file.open(QIODevice::ReadOnly);
    QTextStream stream(&file);
    QString text = stream.readAll();
    // Split list
    QStringList list = text.split("\n");
    // Load items into list
    foreach (QString item, list) {
        if(item.trimmed() != ""){
            ui->GroceryList->addItem(item);
        }
    }
    // get list of saved files
    QStringList file_list = this->get_all_meal_files();
    // Empty text box
    ui->TextBox->setText("");
    // Iterate through each file
    foreach (QString filename, file_list) {
        // Find file that matches current selected date
        if(ui->Calendar->selectedDate().toString() == filename.split(".")[0]){
            // Set textbox to file contents
            ui->TextBox->setText(this->load_file_text(this->meal_save_path + filename));
        }
    }
}
MainWindow::~MainWindow()
{
    delete ui;
}

// Actions
QStringList MainWindow::get_all_meal_files()
{
    QDir directory(this->meal_save_path);
    QStringList files = directory.entryList(QStringList() << "*.txt", QDir::Files);

    return files;
}
QString MainWindow::load_file_text(QString filepath)
{
    QFile file(filepath);
    file.open(QIODevice::ReadOnly);

    QTextStream stream(&file);
    QString file_text = stream.readAll();
    file.close();

    return file_text;
}
void MainWindow::save_grocery_list()
{
    QFile file(this->list_save_path);
    file.open(QIODevice::WriteOnly | QIODevice::Text);
    QTextStream stream(&file);

    QString item_list;
    for(int i=0; i<ui->GroceryList->count(); i++){
        item_list.append(ui->GroceryList->item(i)->text());
        item_list.append("\n");
    }
    item_list = item_list.trimmed();

    stream << item_list;
    file.close();

}

// Modes
void MainWindow::set_mode_readonly(){
    ui->SaveButton->setEnabled(false);
    ui->EditButton->setEnabled(true);
    ui->TextBox->setReadOnly(true);
}
void MainWindow::set_mode_edit(){
    ui->SaveButton->setEnabled(true);
    ui->EditButton->setEnabled(false);
    ui->TextBox->setReadOnly(false);
}

// BUTTONS ----
//
// Grocery List
// ------- ----
// Add Grocery Item
void MainWindow::on_AddItemButton_clicked()
{
    QInputDialog dialog;

    dialog.setLabelText("Enter Item Name");
    dialog.setWindowTitle("Add Item");

    dialog.exec();

    if(dialog.result()){

        QString item_name = dialog.textValue();
        if(item_name.trimmed() != ""){
            ui->GroceryList->addItem(item_name);
        }
    }

    this->save_grocery_list();
}
// Delete Grocery Item
void MainWindow::on_DeleteItemButton_clicked()
{

    int i = ui->GroceryList->currentRow();
    ui->GroceryList->takeItem(i);

    this->save_grocery_list();

}

// Clear Grocery List
void MainWindow::on_ClearListButton_clicked()
{
    QMessageBox::StandardButton confirm;
    confirm = QMessageBox::question(this, "Clear List", "Are you sure you want to clear the list?", QMessageBox::Yes|QMessageBox::No);

    if(confirm == QMessageBox::Yes){
        ui->GroceryList->clear();
    }

    this->save_grocery_list();
}
//
// Text Editor
// ---- ------
// Save Text File
void MainWindow::on_EditButton_clicked()
{
    set_mode_edit();
}
// Edit text file
void MainWindow::on_SaveButton_clicked()
{
    // Set editor to read-only
    set_mode_readonly();

    // Get name to save file as
    QString new_filename = ui->Calendar->selectedDate().toString();

    // Open file to save in
    QFile file(this->meal_save_path + "/" + new_filename + ".txt");
    file.open(QIODevice::WriteOnly | QIODevice::Text);
    QTextStream stream(&file);

    // Write textbox to file
    stream << ui->TextBox->toPlainText();

    // Close file
    file.close();

}
//
// Calendar
// --------
// Select Date
void MainWindow::on_Calendar_selectionChanged()
{

    // Set editor to read-only
    set_mode_readonly();
    // get list of saved files
    QStringList file_list = this->get_all_meal_files();
    // Empty text box
    ui->TextBox->setText("");
    // Iterate through each file
    foreach (QString filename, file_list) {
        // Find file that matches current selected date
        if(ui->Calendar->selectedDate().toString() == filename.split(".")[0]){
            // Set textbox to file contents
            ui->TextBox->setText(this->load_file_text(this->meal_save_path + filename));
        }
    }
}
